import os
import sys
import random
import string
import stat

def is_admin():
    """Check if the script is running as administrator/root."""
    if os.name == 'nt':
        try:
            import ctypes
            return ctypes.windll.shell32.IsUserAnAdmin()
        except Exception:
            return False
    else:
        return os.geteuid() == 0

if not is_admin():
    if os.name == 'nt':
        print("Please run this program as administrator!\nRight click the terminal or cmd and choose 'Run as administrator'.")
    else:
        print("Please run this program as root!\nTry: sudo python3 delete.py")
    sys.exit(1)

def random_filename(length=16):
    """Generate a random filename."""
    chars = string.ascii_letters + string.digits
    return ''.join(random.choice(chars) for _ in range(length))

def remove_readonly(file_path):
    """Remove read-only attribute from a file or directory."""
    try:
        if os.name == 'nt':
            import ctypes
            FILE_ATTRIBUTE_NORMAL = 0x80
            ctypes.windll.kernel32.SetFileAttributesW(str(file_path), FILE_ATTRIBUTE_NORMAL)
        os.chmod(file_path, stat.S_IWRITE | stat.S_IREAD)
    except Exception as e:
        print(f"Warning: Failed to remove read-only attribute for {file_path}: {e}")

def secure_delete(file_path, passes=3):
    """Securely delete a file by overwriting, renaming, and removing it."""
    if not os.path.isfile(file_path):
        print(f"File not found: {file_path}")
        return
    try:
        remove_readonly(file_path)
        length = os.path.getsize(file_path)
        dir_name = os.path.dirname(file_path)
        temp_path = file_path
        for p in range(passes):
            random_name = random_filename() + ".del"
            random_path = os.path.join(dir_name, random_name)
            os.rename(temp_path, random_path)
            with open(random_path, "r+b", buffering=0) as f:
                f.seek(0)
                if p == 0:
                    f.write(b'\x00' * length)
                elif p == 1:
                    f.write(b'\xFF' * length)
                else:
                    f.write(os.urandom(length))
                f.flush()
                os.fsync(f.fileno())
            temp_path = random_path
        with open(temp_path, "r+b", buffering=0) as f:
            shrink_len = random.randint(0, length)
            f.truncate(shrink_len)
            f.flush()
            os.fsync(f.fileno())
        final_name = random_filename() + ".del"
        final_path = os.path.join(dir_name, final_name)
        os.rename(temp_path, final_path)
        remove_readonly(final_path)
        os.remove(final_path)
        if os.name == 'posix':
            os.sync()
        print(f"File securely deleted: {file_path}")
    except PermissionError:
        print(f"Permission denied. Unable to delete the file: {file_path}")
    except Exception as e:
        print(f"An error occurred: {e}")

def secure_delete_folder(folder_path, passes=3):
    """Recursively securely delete a folder and all its contents."""
    if not os.path.isdir(folder_path):
        print(f"Folder not found: {folder_path}")
        return
    failed_items = []
    for root, dirs, files in os.walk(folder_path, topdown=False):
        for name in files:
            file_path = os.path.join(root, name)
            try:
                remove_readonly(file_path)
                secure_delete(file_path, passes)
            except Exception as e:
                print(f"Failed to securely delete file: {file_path}: {e}")
                failed_items.append(file_path)
        for name in dirs:
            dir_path = os.path.join(root, name)
            try:
                remove_readonly(dir_path)
                os.rmdir(dir_path)
            except Exception as e:
                print(f"Failed to delete directory: {dir_path}: {e}")
                failed_items.append(dir_path)
    try:
        remove_readonly(folder_path)
        os.rmdir(folder_path)
        print(f"Folder securely deleted: {folder_path}")
    except Exception as e:
        print(f"An error occurred deleting folder: {e}")
        failed_items.append(folder_path)
    if failed_items:
        print("Some items could not be securely deleted:")
        for item in failed_items:
            print(f"  {item}")

def print_menu():
    print("\nThis is a Secure File Delete Application!")
    print("Welcome!")
    print("Options:")
    print("  1. Securely delete a file or folder")
    print("  quit. Exit the program")

if __name__ == "__main__":
    print_menu()
    while True:
        que = input("\nPlease input the number (or 'quit' to exit): ").strip().lower()
        if que == "quit":
            print("Bye!")
            break
        elif que == "1":
            print("You want to securely delete a file or folder. Now give me the path. For example: D:\\game.exe or D:\\myfolder")
            path = input("The path: ").strip()
            if os.path.isfile(path):
                secure_delete(path)
            elif os.path.isdir(path):
                secure_delete_folder(path)
            else:
                print("File or folder not found. Please check the path and try again.")
        else:
            print("Invalid input. Please input 1 to securely delete a file or folder.")